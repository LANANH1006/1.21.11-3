package com.donutlike;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;

import java.util.HashSet;
import java.util.Random;

/**
 * Can cu rai rac kieu DonutSMP.
 * - Map duoc chia thanh o luoi CELL x CELL. Moi o co xac suat BASE_CHANCE co 1 can cu (co dinh theo seed the gioi).
 * - Khi nguoi choi den gan (TRIGGER_DIST) thi can cu moi duoc xay (1 lan duy nhat, luu o save.baseCells).
 * - 3 kieu: WOOD (nha go nho), STONE (2 tang gach da), OBSIDIAN (ham obsidian loot xin).
 * - Moi kieu co the NGUYEN VEN hoac BI RAID (tuong thung, ruong bi lay do, mang nhen, ho bom, vun da).
 */
public class Bases {

    static final int CELL = 112;
    static final double BASE_CHANCE = 0.85;
    static final int TRIGGER_DIST = 80;

    enum Style { WOOD, STONE, OBSIDIAN, KELP, COBBLE, VAULT, FORT }

    record Result(BlockPos pos, Style style, boolean raided) {}

    static final Item[] WOOD_LOOT = {Items.COAL, Items.BREAD, Items.ARROW, Items.COOKED_BEEF, Items.IRON_INGOT,
            Items.GOLD_INGOT, Items.TORCH, Items.ENDER_PEARL, Items.DIAMOND};
    static final Item[] STONE_LOOT = {Items.COOKED_BEEF, Items.IRON_INGOT, Items.ARROW, Items.GOLD_INGOT, Items.EXPERIENCE_BOTTLE,
            Items.EMERALD, Items.OBSIDIAN, Items.ENDER_PEARL, Items.IRON_SWORD, Items.GOLDEN_APPLE, Items.DIAMOND};
    static final Item[] OBS_LOOT = {Items.OBSIDIAN, Items.EMERALD, Items.ENDER_PEARL, Items.GOLDEN_APPLE, Items.DIAMOND,
            Items.DIAMOND_SWORD, Items.TOTEM_OF_UNDYING, Items.ENCHANTED_GOLDEN_APPLE, Items.NETHERITE_INGOT};
    static final Item[] JUNK = {Items.ROTTEN_FLESH, Items.STICK, Items.ARROW, Items.COAL, Items.BONE, Items.STRING, Items.COBWEB};

    // ===== Rai rac theo nguoi choi =====
    /** Goi moi 2 giay. Xay can cu moi khi nguoi choi den gan o luoi chua xu ly. */
    static void scatterTick(MinecraftServer s) {
        ServerWorld w = s.getOverworld();
        if (DonutLike.save.baseCells == null) DonutLike.save.baseCells = new HashSet<>();
        for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) {
            if (p.getEntityWorld() != w) continue;
            int cx0 = Math.floorDiv(p.getBlockX(), CELL), cz0 = Math.floorDiv(p.getBlockZ(), CELL);
            for (int cx = cx0 - 1; cx <= cx0 + 1; cx++) {
                for (int cz = cz0 - 1; cz <= cz0 + 1; cz++) {
                    String key = cx + "," + cz;
                    if (DonutLike.save.baseCells.contains(key)) continue;
                    Random r = new Random(w.getSeed() * 31L + cx * 341873128712L + cz * 132897987541L);
                    int bx = cx * CELL + 24 + r.nextInt(CELL - 48);
                    int bz = cz * CELL + 24 + r.nextInt(CELL - 48);
                    double dx = bx - p.getX(), dz = bz - p.getZ();
                    if (dx * dx + dz * dz > (double) TRIGGER_DIST * TRIGGER_DIST) continue;
                    DonutLike.save.baseCells.add(key); // danh dau da xu ly (co base hay khong)
                    if (r.nextDouble() > BASE_CHANCE) continue;
                    if (Math.abs(bx) < 64 && Math.abs(bz) < 64) continue; // khong xay sat spawn
                    Style st = randomStyle(r);
                    boolean raided = r.nextDouble() < (st == Style.OBSIDIAN ? 0.30 : 0.50);
                    tryPlace(w, bx, bz, st, raided, r);
                }
            }
        }
    }

    static Style randomStyle(Random r) {
        // can cu kieu nguoi choi Donut hay dung: farm kelp, cobble gen, ham ngam, phao dai (khong con nha go lo)
        double d = r.nextDouble();
        return d < 0.28 ? Style.KELP : d < 0.55 ? Style.COBBLE : d < 0.70 ? Style.VAULT : d < 0.86 ? Style.FORT : d < 0.94 ? Style.STONE : Style.OBSIDIAN;
    }

    // ===== Sinh 1 can cu gan 1 vi tri (dung cho /randombase va su kien dinh ky) =====
    /** raidedOpt: null = ngau nhien, true = bi raid, false = nguyen ven. */
    static Result spawnNear(ServerWorld w, BlockPos origin, int minD, int maxD, Boolean raidedOpt) {
        Random r = DonutLike.R;
        for (int attempt = 0; attempt < 8; attempt++) {
            double ang = r.nextDouble() * Math.PI * 2;
            int d = minD + r.nextInt(Math.max(1, maxD - minD));
            int x = origin.getX() + (int) (Math.cos(ang) * d);
            int z = origin.getZ() + (int) (Math.sin(ang) * d);
            Style st = randomStyle(r);
            boolean raided = raidedOpt != null ? raidedOpt : r.nextDouble() < (st == Style.OBSIDIAN ? 0.30 : 0.50);
            Result res = tryPlace(w, x, z, st, raided, r);
            if (res != null) return res;
        }
        return null;
    }

    static int half(Style st) { return st == Style.STONE ? 4 : (st == Style.KELP || st == Style.COBBLE || st == Style.VAULT || st == Style.FORT) ? 6 : 3; }

    /** Tim cho bang phang, khong nuoc roi xay. Tra null neu dia hinh khong hop. */
    static Result tryPlace(ServerWorld w, int x, int z, Style st, boolean raided, Random r) {
        int h = half(st);
        w.getChunk(x >> 4, z >> 4);
        int y = w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
        int min = y, max = y;
        int[][] pts = {{h, h}, {h, -h}, {-h, h}, {-h, -h}};
        for (int[] pt : pts) {
            int px = x + pt[0], pz = z + pt[1];
            w.getChunk(px >> 4, pz >> 4);
            int ty = w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, px, pz);
            min = Math.min(min, ty); max = Math.max(max, ty);
            if (!w.getFluidState(new BlockPos(px, ty - 1, pz)).isEmpty()) return null;
        }
        if (max - min > 5) return null;
        if (!w.getFluidState(new BlockPos(x, y - 1, z)).isEmpty()) return null;
        if (y <= w.getSeaLevel() - 1) return null;
        BlockPos c = new BlockPos(x, y, z);
        if (st == Style.KELP || st == Style.COBBLE || st == Style.VAULT || st == Style.FORT) buildNice(w, c, st, raided, r);
        else build(w, c, st, raided, r);
        return new Result(c, st, raided);
    }

    // ===== Xay can cu =====
    static void build(ServerWorld w, BlockPos c, Style st, boolean raided, Random r) {
        int h = half(st);
        int wallH = st == Style.STONE ? 6 : 3;
        int roofY = wallH + 1;
        Block baseWall = switch (st) {
            case WOOD -> pick(r, Blocks.OAK_PLANKS, Blocks.SPRUCE_PLANKS, Blocks.BIRCH_PLANKS);
            case STONE -> Blocks.STONE_BRICKS;
            case OBSIDIAN -> Blocks.OBSIDIAN;
        };
        double holeP = raided ? (st == Style.OBSIDIAN ? 0.06 : 0.28) : 0;
        double roofHoleP = raided ? (st == Style.OBSIDIAN ? 0.04 : 0.20) : 0;

        // 1) don dep thể tich phia tren (cay, la, dat cao) + nen mong
        for (int dx = -h - 1; dx <= h + 1; dx++)
            for (int dz = -h - 1; dz <= h + 1; dz++) {
                for (int dy = 0; dy <= roofY + 4; dy++) DonutLike.set(w, c.add(dx, dy, dz), Blocks.AIR);
                if (Math.abs(dx) <= h && Math.abs(dz) <= h)
                    for (int dy = -6; dy <= -1; dy++)
                        DonutLike.set(w, c.add(dx, dy, dz),
                                raided && r.nextDouble() < 0.3 ? Blocks.MOSSY_COBBLESTONE : Blocks.COBBLESTONE);
            }

        // 2) tuong + cua so + mai
        for (int dx = -h; dx <= h; dx++)
            for (int dz = -h; dz <= h; dz++) {
                boolean edge = Math.abs(dx) == h || Math.abs(dz) == h;
                boolean corner = Math.abs(dx) == h && Math.abs(dz) == h;
                for (int dy = 0; dy <= wallH; dy++) {
                    if (!edge) continue;
                    boolean door = dx == 0 && dz == -h && dy <= 1;
                    if (door) continue;
                    if (raided && dy >= 1 && r.nextDouble() < holeP) continue; // tuong bi dap thung
                    boolean window = st != Style.OBSIDIAN && !corner && dy % 3 == 1 && Math.floorMod(dx + dz, 2) == 1;
                    if (window) {
                        if (raided && r.nextDouble() < 0.6) continue; // kinh vo
                        DonutLike.set(w, c.add(dx, dy, dz), Blocks.GLASS_PANE);
                    } else {
                        DonutLike.set(w, c.add(dx, dy, dz), wallBlock(st, baseWall, raided, r));
                    }
                }
                if (!(raided && r.nextDouble() < roofHoleP))
                    DonutLike.set(w, c.add(dx, roofY, dz), wallBlock(st, baseWall, raided, r));
            }

        // 3) tang 2 + thang (chi kieu STONE)
        if (st == Style.STONE) {
            for (int dx = -h + 1; dx <= h - 1; dx++)
                for (int dz = -h + 1; dz <= h - 1; dz++) {
                    if (dx == h - 1 && dz == h - 1) continue; // lo thang
                    if (raided && r.nextDouble() < 0.15) continue;
                    DonutLike.set(w, c.add(dx, 3, dz), Blocks.OAK_PLANKS);
                }
            for (int dy = 0; dy <= 4; dy++) DonutLike.set(w, c.add(h - 1, dy, h - 1), Blocks.LADDER);
        }

        // 4) noi that
        int e = h - 1;
        if (!raided || r.nextBoolean()) DonutLike.set(w, c.add(-e, 0, -e), Blocks.CRAFTING_TABLE);
        if (!raided || r.nextBoolean()) DonutLike.set(w, c.add(e, 0, -e), Blocks.FURNACE);
        if (!raided || r.nextDouble() < 0.25) {
            DonutLike.set(w, c.add(e, 0, 0), Blocks.TORCH);
            DonutLike.set(w, c.add(-e, 0, 0), Blocks.TORCH);
            if (st == Style.STONE) {
                DonutLike.set(w, c.add(e, 4, 0), Blocks.TORCH);
                DonutLike.set(w, c.add(-e, 4, 0), Blocks.TORCH);
            }
        }

        // 5) ruong
        Item[] loot = st == Style.WOOD ? WOOD_LOOT : st == Style.STONE ? STONE_LOOT : OBS_LOOT;
        java.util.List<BlockPos> spots = new java.util.ArrayList<>();
        spots.add(c.add(-e, 0, e));
        spots.add(c.add(0, 0, e));
        if (st == Style.STONE) { spots.add(c.add(-e, 4, e)); spots.add(c.add(0, 4, e)); spots.add(c.add(-e, 4, -e)); }
        int nChest = switch (st) { case WOOD -> 1 + r.nextInt(2); case STONE -> 2 + r.nextInt(3); case OBSIDIAN -> 2 + r.nextInt(2); };
        java.util.Collections.shuffle(spots, r);
        for (int i = 0; i < Math.min(nChest, spots.size()); i++) {
            BlockPos cp = spots.get(i);
            if (raided) {
                double roll = r.nextDouble();
                if (roll < 0.40) continue;            // ruong bi lay mat luon
                chest(w, cp, JUNK, r.nextInt(3), r);  // chi con rac
                if (roll > 0.85) chestAdd(w, cp, loot, 1, r); // thinh thoang sot lai 1 mon
            } else {
                chest(w, cp, loot, 3 + r.nextInt(st == Style.OBSIDIAN ? 6 : 5), r);
            }
        }

        // 6) hieu ung raid: ho bom, mang nhen, vun
        if (raided) {
            if (st != Style.OBSIDIAN && r.nextDouble() < 0.5) {
                int sx = r.nextBoolean() ? h : -h, sz = r.nextBoolean() ? h : -h;
                for (int dx = -2; dx <= 2; dx++)
                    for (int dy = -1; dy <= 3; dy++)
                        for (int dz = -2; dz <= 2; dz++) {
                            if (dx * dx + dy * dy + dz * dz > 5) continue;
                            BlockPos p = c.add(sx + dx, 1 + dy, sz + dz);
                            if (w.getBlockState(p).isOf(Blocks.CHEST)) continue;
                            DonutLike.set(w, p, Blocks.AIR);
                        }
            }
            for (int i = 0; i < 14; i++) {
                BlockPos p = c.add(r.nextInt(2 * e + 1) - e, r.nextInt(3), r.nextInt(2 * e + 1) - e);
                if (w.getBlockState(p).isAir()) DonutLike.set(w, p, Blocks.COBWEB);
            }
            for (int dx = -h - 2; dx <= h + 2; dx++)
                for (int dz = -h - 2; dz <= h + 2; dz++) {
                    if (Math.abs(dx) <= h && Math.abs(dz) <= h) continue;
                    double d = r.nextDouble();
                    if (d < 0.18) DonutLike.set(w, c.add(dx, -1, dz), Blocks.COARSE_DIRT);
                    else if (d < 0.26) DonutLike.set(w, c.add(dx, -1, dz), Blocks.NETHERRACK);
                }
        }
    }

    // ======================================================================
    //  CAN CU "DEP" (kieu schematic nguoi choi Donut hay dung): KELP / COBBLE / VAULT / FORT
    // ======================================================================
    static final Item[] KELP_LOOT = {Items.DRIED_KELP_BLOCK, Items.KELP, Items.DRIED_KELP, Items.SEA_PICKLE, Items.COAL, Items.IRON_INGOT,
            Items.GOLD_INGOT, Items.ENDER_PEARL, Items.DIAMOND};
    static final Item[] COBBLE_LOOT = {Items.COBBLESTONE, Items.COAL, Items.IRON_INGOT, Items.GOLD_INGOT, Items.REDSTONE, Items.LAPIS_LAZULI,
            Items.IRON_PICKAXE, Items.DIAMOND, Items.ENDER_PEARL};

    static void put(ServerWorld w, BlockPos c, int dx, int dy, int dz, Block b) { DonutLike.set(w, c.add(dx, dy, dz), b); }

    static void box(ServerWorld w, BlockPos c, int x1, int y1, int z1, int x2, int y2, int z2, Block b) {
        for (int x = x1; x <= x2; x++) for (int y = y1; y <= y2; y++) for (int z = z1; z <= z2; z++) put(w, c, x, y, z, b);
    }

    static void lootChest(ServerWorld w, BlockPos p, Item[] loot, boolean raided, Random r, int n) {
        if (raided) {
            double roll = r.nextDouble();
            if (roll < 0.40) return;
            chest(w, p, JUNK, r.nextInt(3), r);
            if (roll > 0.85) chestAdd(w, p, loot, 1, r);
        } else chest(w, p, loot, n, r);
    }

    static void buildNice(ServerWorld w, BlockPos c, Style st, boolean raided, Random r) {
        int h = 6;
        // don mat bang + nen mong
        for (int dx = -h - 1; dx <= h + 1; dx++)
            for (int dz = -h - 1; dz <= h + 1; dz++) {
                for (int dy = 0; dy <= 12; dy++) put(w, c, dx, dy, dz, Blocks.AIR);
                if (st != Style.VAULT && Math.abs(dx) <= h && Math.abs(dz) <= h)
                    for (int dy = -8; dy <= -1; dy++) put(w, c, dx, dy, dz, Blocks.COBBLESTONE);
            }
        switch (st) {
            case KELP -> buildKelp(w, c, raided, r);
            case COBBLE -> buildCobble(w, c, raided, r);
            case VAULT -> buildVault(w, c, raided, r);
            default -> buildFort(w, c, raided, r);
        }
        if (raided) damage(w, c, h, st == Style.VAULT ? 0 : 8, r);
    }

    /** Vo tuong, mang nhen, da vun: giong base bi raid. */
    static void damage(ServerWorld w, BlockPos c, int h, int hMax, Random r) {
        for (int dx = -h - 1; dx <= h + 1; dx++)
            for (int dz = -h - 1; dz <= h + 1; dz++)
                for (int dy = 1; dy <= hMax; dy++) {
                    BlockPos p = c.add(dx, dy, dz);
                    var b = w.getBlockState(p);
                    if (b.isAir() || b.isOf(Blocks.CHEST) || b.isOf(Blocks.WATER) || b.isOf(Blocks.LAVA)) continue;
                    if (r.nextDouble() < 0.10) put(w, c, dx, dy, dz, Blocks.AIR);
                }
        for (int i = 0; i < 18; i++) {
            BlockPos p = c.add(r.nextInt(2 * h - 1) - h + 1, r.nextInt(3), r.nextInt(2 * h - 1) - h + 1);
            if (w.getBlockState(p).isAir()) DonutLike.set(w, p, Blocks.COBWEB);
        }
    }

    /** Hop 13x13: tuong deepslate, kinh, cua o giua mat nam (dz = -6). */
    static void shell(ServerWorld w, BlockPos c, Block wall, Block roof, Block floor, int wallH) {
        int h = 6;
        for (int dx = -h; dx <= h; dx++)
            for (int dz = -h; dz <= h; dz++) {
                put(w, c, dx, -1, dz, floor);
                boolean edge = Math.abs(dx) == h || Math.abs(dz) == h;
                boolean corner = Math.abs(dx) == h && Math.abs(dz) == h;
                for (int dy = 0; dy < wallH && edge; dy++) {
                    boolean door = dx == 0 && dz == -h && dy <= 1;
                    if (door) continue;
                    boolean window = !corner && dy == 2 && Math.floorMod(dx + dz, 2) == 0;
                    put(w, c, dx, dy, dz, window ? Blocks.GLASS : wall);
                }
                put(w, c, dx, wallH, dz, roof);
            }
        put(w, c, 0, 2, -h, wall); // thanh ngang tren cua
        put(w, c, -1, 0, -h - 1, Blocks.LANTERN);
        put(w, c, 1, 0, -h - 1, Blocks.LANTERN);
    }

    // ---- 1) KELP: be nuoc 7x7 chim, kelp moc, bep lo xung quanh ----
    static void buildKelp(ServerWorld w, BlockPos c, boolean raided, Random r) {
        shell(w, c, Blocks.DEEPSLATE_BRICKS, Blocks.DEEPSLATE_TILES, Blocks.STONE_BRICKS, 5);
        for (int dx = -3; dx <= 3; dx++)
            for (int dz = -3; dz <= 3; dz++) {
                put(w, c, dx, -6, dz, Blocks.SAND);
                for (int dy = -5; dy <= -1; dy++) put(w, c, dx, dy, dz, Blocks.WATER);
                if (Math.floorMod(dx + dz, 2) == 0) {
                    for (int dy = -5; dy <= -3; dy++) put(w, c, dx, dy, dz, Blocks.KELP_PLANT);
                    put(w, c, dx, -2, dz, Blocks.KELP);
                }
            }
        for (int dx = -4; dx <= 4; dx += 2) put(w, c, dx, 0, 5, dx % 4 == 0 ? Blocks.SMOKER : Blocks.FURNACE);
        for (int dx : new int[]{-3, 3}) put(w, c, dx, 4, 0, Blocks.SEA_LANTERN);
        put(w, c, 0, 4, -3, Blocks.SEA_LANTERN); put(w, c, 0, 4, 3, Blocks.SEA_LANTERN);
        for (int[] p : new int[][]{{-5, -5}, {5, -5}, {-5, 4}, {5, 4}})
            lootChest(w, c.add(p[0], 0, p[1]), KELP_LOOT, raided, r, 4 + r.nextInt(5));
        put(w, c, 4, 0, 4, Blocks.CRAFTING_TABLE);
    }

    // ---- 2) COBBLE: 3 may phat cobble (lava | da | nuoc) trong ham xay gach ----
    static void buildCobble(ServerWorld w, BlockPos c, boolean raided, Random r) {
        shell(w, c, Blocks.STONE_BRICKS, Blocks.STONE_BRICKS, Blocks.POLISHED_ANDESITE, 5);
        box(w, c, -5, 0, 4, 5, 1, 4, Blocks.STONE_BRICKS); // tuong sau cho may phat
        for (int gx : new int[]{-4, 0, 4}) {
            // tuong 2 ben + chan lo/nuoc (khong cho chay ra ngoai)
            for (int sx : new int[]{-2, 2}) box(w, c, gx + sx, 0, 2, gx + sx, 1, 3, Blocks.STONE_BRICKS);
            put(w, c, gx - 1, 0, 3, Blocks.LAVA);
            put(w, c, gx + 1, 0, 3, Blocks.WATER);
            put(w, c, gx, 0, 3, Blocks.COBBLESTONE);          // vien da: dao xong tu sinh lai
            for (int sx : new int[]{-1, 1}) {
                put(w, c, gx + sx, 1, 3, Blocks.STONE_BRICKS); // nap tren lo/nuoc
                box(w, c, gx + sx, 0, 2, gx + sx, 1, 2, Blocks.STONE_BRICKS); // chan truoc
            }
            put(w, c, gx, 1, 3, Blocks.AIR);
        }
        put(w, c, -5, 0, -4, Blocks.CRAFTING_TABLE); put(w, c, 5, 0, -4, Blocks.FURNACE);
        for (int[] p : new int[][]{{-5, -2}, {5, -2}, {-5, 0}, {5, 0}})
            lootChest(w, c.add(p[0], 0, p[1]), COBBLE_LOOT, raided, r, 4 + r.nextInt(5));
        for (int dx : new int[]{-3, 3}) put(w, c, dx, 4, -2, Blocks.SEA_LANTERN);
    }

    // ---- 3) VAULT: nha nho tren mat, gieng thang xuong ham obsidian/deepslate ----
    static void buildVault(ServerWorld w, BlockPos c, boolean raided, Random r) {
        // nha nho 3x3 che mieng gieng
        for (int dx = -2; dx <= 2; dx++)
            for (int dz = -2; dz <= 2; dz++) {
                boolean edge = Math.abs(dx) == 2 || Math.abs(dz) == 2;
                put(w, c, dx, -1, dz, Blocks.COBBLESTONE);
                for (int dy = 0; dy <= 2 && edge; dy++) if (!(dx == 0 && dz == -2 && dy <= 1)) put(w, c, dx, dy, dz, Blocks.STONE_BRICKS);
                put(w, c, dx, 3, dz, Blocks.STONE_BRICKS);
            }
        // gieng + thang
        for (int dy = -9; dy <= -1; dy++) {
            put(w, c, 0, dy, 0, Blocks.AIR);
            put(w, c, 0, dy, 1, Blocks.STONE_BRICKS); put(w, c, 1, dy, 0, Blocks.STONE_BRICKS);
            put(w, c, -1, dy, 0, Blocks.STONE_BRICKS); put(w, c, 0, dy, -1, Blocks.STONE_BRICKS);
            DonutLike.set(w, c.add(0, dy, 0), Blocks.LADDER.getDefaultState().with(net.minecraft.block.HorizontalFacingBlock.FACING, net.minecraft.util.math.Direction.NORTH));
        }
        // ham ngam 9x9 (vo deepslate + obsidian)
        box(w, c, -5, -14, -5, 5, -8, 5, Blocks.DEEPSLATE_BRICKS);
        box(w, c, -4, -13, -4, 4, -9, 4, Blocks.AIR);
        for (int[] p : new int[][]{{-5, -5}, {5, -5}, {-5, 5}, {5, 5}}) box(w, c, p[0], -14, p[1], p[0], -8, p[1], Blocks.OBSIDIAN);
        box(w, c, -4, -14, -4, 4, -14, 4, Blocks.OBSIDIAN);
        for (int dy = -8; dy <= -1; dy++) // thang qua tran ham (dy=-8 la lop tran)
            DonutLike.set(w, c.add(0, dy, 0), Blocks.LADDER.getDefaultState().with(net.minecraft.block.HorizontalFacingBlock.FACING, net.minecraft.util.math.Direction.NORTH));
        for (int[] p : new int[][]{{-3, -3}, {3, -3}, {-3, 3}, {3, 3}}) put(w, c, p[0], -9, p[1], Blocks.SEA_LANTERN);
        for (int[] p : new int[][]{{-3, -4}, {3, -4}, {-4, 0}, {4, 0}, {-3, 4}, {3, 4}, {0, 4}})
            lootChest(w, c.add(p[0], -13, p[1]), OBS_LOOT, raided, r, 5 + r.nextInt(6));
    }

    // ---- 4) FORT: phao dai tuong da, thap goc, gieng nuoc giua san ----
    static void buildFort(ServerWorld w, BlockPos c, boolean raided, Random r) {
        int h = 6;
        for (int dx = -h; dx <= h; dx++)
            for (int dz = -h; dz <= h; dz++) {
                put(w, c, dx, -1, dz, Blocks.STONE_BRICKS);
                boolean edge = Math.abs(dx) == h || Math.abs(dz) == h;
                if (!edge) continue;
                for (int dy = 0; dy <= 4; dy++) {
                    boolean gate = dz == -h && Math.abs(dx) <= 1 && dy <= 2;
                    if (!gate) put(w, c, dx, dy, dz, dy == 2 && Math.floorMod(dx + dz, 3) == 0 ? Blocks.CRACKED_STONE_BRICKS : Blocks.STONE_BRICKS);
                }
                if (Math.floorMod(dx + dz, 2) == 0) put(w, c, dx, 5, dz, Blocks.STONE_BRICKS); // rang cua
            }
        // thap goc 3x3, cao 8
        for (int sx : new int[]{-1, 1})
            for (int sz : new int[]{-1, 1}) {
                for (int ax = 4; ax <= 6; ax++)
                    for (int az = 4; az <= 6; az++) {
                        int x = sx * ax, z = sz * az;
                        boolean center = ax == 5 && az == 5;
                        for (int dy = 0; dy <= 7; dy++) put(w, c, x, dy, z, center ? Blocks.AIR : Blocks.DEEPSLATE_BRICKS);
                        put(w, c, x, 8, z, center ? Blocks.DEEPSLATE_TILES : ((ax + az) % 2 == 0 ? Blocks.DEEPSLATE_BRICKS : Blocks.AIR));
                    }
                put(w, c, sx * 4, 0, sz * 5, Blocks.AIR); put(w, c, sx * 4, 1, sz * 5, Blocks.AIR); // cua vao thap
                put(w, c, sx * 5, 6, sz * 5, Blocks.SEA_LANTERN);
                lootChest(w, c.add(sx * 5, 0, sz * 5), STONE_LOOT, raided, r, 4 + r.nextInt(6));
            }
        // gieng giua san
        for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) put(w, c, dx, 0, dz, Blocks.COBBLESTONE);
        put(w, c, 0, 0, 0, Blocks.WATER); put(w, c, 0, -1, 0, Blocks.WATER);
        put(w, c, -1, 0, -h - 1, Blocks.LANTERN); put(w, c, 1, 0, -h - 1, Blocks.LANTERN);
        lootChest(w, c.add(0, 0, 4), STONE_LOOT, raided, r, 3 + r.nextInt(4));
    }

    static Block wallBlock(Style st, Block base, boolean raided, Random r) {
        if (raided && st == Style.STONE) {
            double d = r.nextDouble();
            return d < 0.30 ? Blocks.CRACKED_STONE_BRICKS : d < 0.50 ? Blocks.MOSSY_STONE_BRICKS : base;
        }
        return base;
    }

    static Block pick(Random r, Block... bs) { return bs[r.nextInt(bs.length)]; }

    /** Dat ruong va do n mon (mon hiem o cuoi mang, de ra it hon). */
    static void chest(ServerWorld w, BlockPos p, Item[] loot, int n, Random r) {
        DonutLike.set(w, p, Blocks.CHEST);
        chestAdd(w, p, loot, n, r);
    }

    static void chestAdd(ServerWorld w, BlockPos p, Item[] loot, int n, Random r) {
        if (!(w.getBlockEntity(p) instanceof ChestBlockEntity ch)) return;
        for (int i = 0; i < n; i++) {
            Item it = loot[Math.min(r.nextInt(loot.length), r.nextInt(loot.length))];
            int cnt = Math.min(it.getMaxCount(), 1 + r.nextInt(5));
            ch.setStack(r.nextInt(27), new ItemStack(it, cnt));
        }
    }
}
