package com.donutlike;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static net.minecraft.server.command.CommandManager.literal;

/**
 * /sellgui (cung la /sell): mo 1 ruong de bo do vao. Dong ruong (ESC hoac E) la BAN HET.
 * - Moi vat pham co 1 gia rieng (Prices). Do khong co gia / khong ban duoc se tra lai vao tui.
 * - Sell multiplier: ban cang nhieu mon thi he so cang cao, toi da x3. Xem bang /sellmulti.
 */
public class SellGui {

    static final double MAX_MULT = 3.0;
    /** Ban het bao nhieu mon thi dat he so toi da (x3). */
    static final double ITEMS_FOR_MAX = 6000;
    static final int ITEM_SLOTS = 45; // 0..44 = cho bo do; 45..53 = thanh thong tin

    // ===== he so =====
    static long sold(UUID id) {
        if (DonutLike.save.soldItems == null) DonutLike.save.soldItems = new java.util.HashMap<>();
        return DonutLike.save.soldItems.getOrDefault(id.toString(), 0L);
    }

    static double mult(UUID id) {
        double m = 1.0 + (MAX_MULT - 1.0) * Math.min(1.0, sold(id) / ITEMS_FOR_MAX);
        return Math.min(MAX_MULT, Math.round(m * 1000.0) / 1000.0);
    }

    /** Gia 1 stack khi ban (chua nhan he so). 0 = khong ban duoc. */
    static double priceOf(ItemStack s) {
        if (s == null || s.isEmpty()) return 0;
        if (s.get(DataComponentTypes.CUSTOM_DATA) != null) return 0;            // do dac biet (Amethyst, to sec, ve rank...)
        if (Prices.unit(s.getItem()) <= 0) return 0;
        if (s.hasEnchantments() && Enchants.premiumGear(s.getItem())) return Prices.enchUnit(s.getItem()) * s.getCount();
        return Prices.stack(s);
    }

    static ItemStack filler() { return ShopHandler.icon(Items.GRAY_STAINED_GLASS_PANE, " "); }

    static boolean isFiller(ItemStack s) {
        return s.isOf(Items.GRAY_STAINED_GLASS_PANE) && s.get(DataComponentTypes.CUSTOM_NAME) != null
            && " ".equals(s.get(DataComponentTypes.CUSTOM_NAME).getString());
    }

    static void open(ServerPlayerEntity p) {
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
            (id, inv, pl) -> new Gui(id, inv, new SimpleInventory(54), pl.getUuid()),
            Text.literal("Sell - bỏ đồ vào, đóng (ESC/E) là bán")));
    }

    static class Gui extends GenericContainerScreenHandler {
        final SimpleInventory inv; final UUID owner; boolean sold = false;

        Gui(int id, PlayerInventory pinv, SimpleInventory inv, UUID owner) {
            super(ScreenHandlerType.GENERIC_9X6, id, pinv, inv, 6);
            this.inv = inv; this.owner = owner;
            for (int i = 0; i < ITEM_SLOTS; i++) inv.setStack(i, ItemStack.EMPTY);
            for (int i = ITEM_SLOTS; i < 54; i++) inv.setStack(i, filler());
            refresh();
        }

        double rawTotal() {
            double t = 0;
            for (int i = 0; i < ITEM_SLOTS; i++) t += priceOf(inv.getStack(i));
            return t;
        }

        void refresh() {
            double raw = rawTotal();
            double m = mult(owner);
            List<Text> lore = new ArrayList<>();
            lore.add(Text.literal("§7Giá gốc: §f$" + Prices.money(raw)));
            lore.add(Text.literal("§7Sell multi: §ex" + String.format("%.2f", m) + " §7(tối đa x" + (int) MAX_MULT + ")"));
            lore.add(Text.literal("§aSẽ nhận: §e$" + Prices.money(raw * m)));
            lore.add(Text.literal("§8Đóng ESC hoặc E để bán"));
            ItemStack total = new ItemStack(Items.GOLD_INGOT);
            total.set(DataComponentTypes.CUSTOM_NAME, Text.literal("§6§lTổng bán"));
            total.set(DataComponentTypes.LORE, new LoreComponent(lore));
            inv.setStack(49, total);
            inv.setStack(46, ShopHandler.icon(Items.PAPER, "§eMỗi vật phẩm một giá khác nhau",
                "§7Đồ không có giá sẽ được trả lại túi", "§7Bán càng nhiều, multi càng cao"));
        }

        @Override
        public void onSlotClick(int slotIndex, int button, SlotActionType type, PlayerEntity player) {
            if (slotIndex >= ITEM_SLOTS && slotIndex < 54) { syncState(); return; } // thanh thong tin: khong cham duoc
            super.onSlotClick(slotIndex, button, type, player);
            refresh();
            syncState();
        }

        @Override
        public ItemStack quickMove(PlayerEntity player, int slot) {
            ItemStack ret = ItemStack.EMPTY;
            Slot s = this.slots.get(slot);
            if (s != null && s.hasStack()) {
                ItemStack st = s.getStack();
                ret = st.copy();
                if (slot >= 54) {
                    if (!this.insertItem(st, 0, ITEM_SLOTS, false)) return ItemStack.EMPTY;
                } else {
                    if (!this.insertItem(st, 54, this.slots.size(), true)) return ItemStack.EMPTY;
                }
                if (st.isEmpty()) s.setStack(ItemStack.EMPTY); else s.markDirty();
            }
            return ret;
        }

        @Override
        public void onClosed(PlayerEntity player) {
            if (player instanceof ServerPlayerEntity sp && !sold) {
                sold = true;
                double raw = 0; long count = 0;
                for (int i = 0; i < ITEM_SLOTS; i++) {
                    ItemStack s = inv.removeStack(i);
                    if (s.isEmpty()) continue;
                    double v = priceOf(s);
                    if (v > 0) { raw += v; count += s.getCount(); }
                    else sp.getInventory().offerOrDrop(s); // khong ban duoc -> tra lai
                }
                for (int i = ITEM_SLOTS; i < 54; i++) { // phong ho do bi keo tha vao thanh thong tin
                    ItemStack s = inv.removeStack(i);
                    if (!s.isEmpty() && !isFiller(s) && s.getItem() != Items.GOLD_INGOT && s.getItem() != Items.PAPER) sp.getInventory().offerOrDrop(s);
                }
                if (count > 0) {
                    double m = mult(sp.getUuid());
                    double pay = raw * m;
                    DonutLike.add(sp.getUuid(), pay);
                    DonutLike.save.soldItems.merge(sp.getUuid().toString(), count, Long::sum);
                    ShopHandler.ting(sp);
                    DonutLike.msg(sp, "§a[Sell] Đã bán §f" + count + " §amón: §e+$" + Prices.money(pay)
                        + " §7(giá gốc $" + Prices.money(raw) + " × multi x" + String.format("%.2f", m) + ")"
                        + (mult(sp.getUuid()) > m ? " §d→ multi tăng lên x" + String.format("%.2f", mult(sp.getUuid())) : ""));
                } else {
                    DonutLike.msg(sp, "§7Không có gì để bán.");
                }
            }
            super.onClosed(player);
        }
    }

    static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(literal("sellgui").requires(s -> Admin.on("shop")).executes(c -> { open(c.getSource().getPlayerOrThrow()); return 1; }));
        d.register(literal("sellmulti").executes(c -> {
            ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
            long n = sold(p.getUuid());
            double need = Math.max(0, ITEMS_FOR_MAX - n);
            DonutLike.msg(p, "§6Sell multi: §ex" + String.format("%.2f", mult(p.getUuid())) + " §7(tối đa x" + (int) MAX_MULT + ")\n§7Đã bán: §f" + n
                + " món" + (need > 0 ? " §7- còn §f" + (long) need + " §7món nữa để đạt x" + (int) MAX_MULT : " §a- đã đạt tối đa!"));
            return 1;
        }));
    }
}
