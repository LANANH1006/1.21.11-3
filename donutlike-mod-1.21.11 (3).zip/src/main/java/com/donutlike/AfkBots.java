package com.donutlike;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.Heightmap;

import java.util.List;
import java.util.Random;

/**
 * - Bot AFK ao dung o spawn (hinh nguoi choi) cho giong server Donut thuc.
 * - Don quai vat (hostile) khong co ten quanh spawn, khong de quai tu sinh o spawn.
 * Tat bang /dladmin: "afkbots" va "spawnclean".
 */
public class AfkBots {
    static final String TAG = "dl_afkbot";
    static final int COUNT = 14;

    static void init() { }

    static BlockPos spawnCenter(ServerWorld w) {
        if (DonutLike.save.spawn != null)
            return BlockPos.ofFloored(DonutLike.save.spawn[0], DonutLike.save.spawn[1], DonutLike.save.spawn[2]);
        BlockPos sp = w.getSpawnPoint().getPos();
        return new BlockPos(sp.getX(), w.getTopY(Heightmap.Type.MOTION_BLOCKING, sp.getX(), sp.getZ()), sp.getZ());
    }

    static void tick(MinecraftServer s) {
        if (DonutLike.tick % 100 != 0) return;
        ServerWorld w = s.getOverworld();
        BlockPos c = spawnCenter(w);
        boolean near = false;
        for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList())
            if (p.getEntityWorld() == w && p.squaredDistanceTo(c.getX(), c.getY(), c.getZ()) < 96.0 * 96.0) { near = true; break; }
        if (!near) return;

        if (Admin.on("spawnclean")) {
            int r = Math.max(32, Admin.inum("spawn_radius") + 16);
            Box box = new Box(c.getX() - r, w.getBottomY(), c.getZ() - r, c.getX() + r, w.getTopYInclusive(), c.getZ() + r);
            for (HostileEntity e : w.getEntitiesByClass(HostileEntity.class, box, e -> !e.hasCustomName() && !e.isPersistent())) e.discard();
        }

        if (Admin.on("afkbots") && DonutLike.tick % 600 == 0) {
            Box box = new Box(c.getX() - 40, c.getY() - 20, c.getZ() - 40, c.getX() + 40, c.getY() + 40, c.getZ() + 40);
            List<LivingEntity> old = w.getEntitiesByClass(LivingEntity.class, box, e -> e.getCommandTags().contains(TAG));
            if (old.size() >= COUNT) return;
            for (LivingEntity e : old) e.discard();
            Random r = new Random(c.asLong());
            for (int i = 0; i < COUNT; i++) {
                double ang = r.nextDouble() * Math.PI * 2;
                double d = 5 + r.nextDouble() * 10;
                int x = c.getX() + (int) Math.round(Math.cos(ang) * d), z = c.getZ() + (int) Math.round(Math.sin(ang) * d);
                int y = w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
                var e = EntityType.MANNEQUIN.create(w, SpawnReason.COMMAND);
                if (e == null) return;
                e.refreshPositionAndAngles(x + 0.5, y, z + 0.5, r.nextFloat() * 360f, 0f);
                e.setCustomName(Text.literal("§7" + FakeMarket.FAKE_NAMES[i % FakeMarket.FAKE_NAMES.length]));
                e.setCustomNameVisible(true);
                e.setInvulnerable(true);
                e.setNoGravity(true);
                e.addCommandTag(TAG);
                w.spawnEntity(e);
            }
        }
    }
}
